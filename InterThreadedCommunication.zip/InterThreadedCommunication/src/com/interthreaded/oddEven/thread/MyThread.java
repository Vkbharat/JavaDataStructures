package com.interthreaded.oddEven.thread;

import com.interthreaded.oddEven.service.Print;

public class MyThread extends Thread{
	
	Thread thread=null;
	Print p=null;
	String name;
	
	public MyThread(String name,Print p)
	{
		this.name=name;
		this.p=p;
	}

	public void start()
	{
		if(thread==null)
		{
			thread=new Thread(this,name);
		}
		System.out.println("Called start");
		thread.start();
	}
	
	@Override
	public void run()
	{
		System.out.println("inside run()");
		if(Thread.currentThread().getName().equalsIgnoreCase("Even"))
		{
			try {
				p.printEven();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			try {
				p.printOdd();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
	}
	
}
