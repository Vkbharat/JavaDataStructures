package com.interthreaded.oddEven.Tester;

import com.interthreaded.oddEven.service.Print;
import com.interthreaded.oddEven.thread.MyThread;

public class Test {

	
	public static void main(String[] args) {
		
		Print p=new Print();
		MyThread t1=new MyThread("Even", p);
		MyThread t2=new MyThread("Odd", p);
		t1.start();
		t2.start();
		
	}
	
	
}
