package com.interthreaded.oddEven.service;

public class Print {

	private boolean flag = true;

	public synchronized void printEven() throws InterruptedException {
		for (int i = 0; i <= 10; i += 2) {
			System.out.print(" " + i);
			flag = false;
			if (i != 10) {
				notify();
				wait();
			} else
				System.exit(0);
		}
	}

	public synchronized void printOdd() throws InterruptedException {
		while (flag) {
			wait();
		}
		for (int i = 1; i <= 9; i += 2) {
			System.out.print(" " + i);
			notify();
			wait();
		}
	}
}
