package com.sll.removeduplicates.util;

public class Items {

	Items next;
	int id;

	public Items( int id,Items next) {
		this.next = next;
		this.id = id;
	}

	public Items getNext() {
		return next;
	}

	public void setNext(Items next) {
		this.next = next;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
