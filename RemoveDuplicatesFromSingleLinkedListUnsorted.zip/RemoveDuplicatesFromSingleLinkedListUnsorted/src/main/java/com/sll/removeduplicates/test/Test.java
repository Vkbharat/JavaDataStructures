package com.sll.removeduplicates.test;

import java.util.Scanner;

import com.sll.removeduplicates.service.LinkedList;
import com.sll.removeduplicates.util.Items;

public class Test {
	
	private static boolean flag=true;
	
	public static void main(String[] args) {
		
		LinkedList ll=new LinkedList();
		Items head=null;
		
		while(flag)
		{
			System.out.println("1.To create a list");
			System.out.println("2.To display");
			System.out.println("3.To remove duplicates...");
			System.out.println("4.to Quit");
			
			Scanner sc=new Scanner(System.in);
			int input=sc.nextInt();
			
			switch(input)
			{
			case 1:head=ll.createList(head);
			break;
			case 2:ll.display(head);
			break;
			case 3:ll.removeDuplicates(head);
			break;
			case 4:flag=false;break;
			default:
				flag=false;
				System.out.println("Wrong Entry quitting ");
				
			}
		}
		
	}
}
