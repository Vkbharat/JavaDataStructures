package com.sll.removeduplicates.service;

import java.util.Hashtable;
import java.util.Scanner;
import com.sll.removeduplicates.util.Items;

public class LinkedList {

	public Items createList(Items head) {
		Scanner sc = new Scanner(System.in);

		if (head == null) {
			System.out.println("Enter id: ");
			int id = sc.nextInt();
			return head = new Items(id, null);
		}
		Items tempVar = head;

		System.out.println("Enter id: ");
		int id = sc.nextInt();

		while (tempVar.getNext() != null)
			tempVar = tempVar.getNext();

		tempVar.setNext(new Items(id, null));

		return head;
	}

	public void display(Items head) {
		if (head == null)
			return;

		do {
			System.out.println(head.getId());
			head = head.getNext();
		} while (head != null);
	}

	//duplicates removal with Buffer
	/*
	 * public void removeDuplicates(Items head) {
		Hashtable table = new Hashtable();

		if (head == null)
			return;

		int len = listLength(head);

		if (len == 1) {
			System.out.println("No duplicates to be removed");
			return;
		}
		Items prev=head;
		Items tempRun=head.getNext();
		table.put(prev.getId(), true);

		while (tempRun!=null) {
		if(table.containsKey(tempRun.getId()))
				{
					prev.setNext(tempRun.getNext());
					tempRun=prev.getNext();
					continue;
				}
		table.put(tempRun.getId(), true);
			prev=tempRun;
			tempRun=tempRun.getNext();			
		}
	} */
	
	
	//without any buffer
	public void removeDuplicates(Items head){
		boolean flag=true;
		if(head==null)
			return;
		
		int len=listLength(head);
		
		if (len==1)
		return;
		
		Items prev=head;
		Items tempRunner=head;
		Items current=head.getNext();

		while(current!=null) {
		while(tempRunner!=current)
		{
			if(tempRunner.getId()==current.getId())
			{				
				prev.setNext(current.getNext());	
				flag=false;
				break;
			}
			
			tempRunner=tempRunner.getNext();			
		}
		tempRunner=head;		
		current=current.getNext();
		
		if(flag)
			prev=prev.getNext();
		}		
	}

	public int listLength(Items head) {
		int count = 1;
		if (head == null)
			return 0;

		while (head.getNext() != null) {
			head = head.getNext();
			count++;
		}

		return count;

	}

}
