package com.service;

public class BubbleSortService {
	
	public int[] sortArray(int[] array)
	{		
		System.out.println("length of array: "+array.length);
		
		int limit=array.length;
		
		for (int j = 1; j < limit; j++) {
			for (int i = 0; i < limit-j; i++) {
				if (array[i] > array[i + 1]) {
					swap(array, i, i + 1);
				}
			}
		}
		
		return array;
	}
	
	public void swap(int[] array,int i,int j)
	{
		array[i]+=array[j];
		array[j]=array[i]-array[j];
		array[i]-=array[j];		
	}

}
