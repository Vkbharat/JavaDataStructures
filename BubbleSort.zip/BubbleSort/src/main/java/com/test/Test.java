package com.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.service.BubbleSortService;

public class Test {
	
	public static void main(String[] args) {
		
		int[] array=new int[10];
		
		//popuate array
		array[1]=10;array[2]=-10;array[4]=20;array[6]=110;array[8]=50;
		array[1]=20;array[3]=-1;array[5]=90;array[7]=8;array[9]=70;
		
		System.out.print("Unsorted array: ");
		for(int i:array)
		{
			System.out.print(i+" ");
		}
		System.out.println();
		BubbleSortService bss=new BubbleSortService();
		
		array=bss.sortArray(array);
		System.out.print("Sorted array: ");		
		for(int i:array)
		{
			System.out.print(i+" ");
		}
	}

}
