package com.util;

public class EngineDetails {
	
	int engineId;
	String engineType;
	float enginePrice;
	
	public EngineDetails(int engineId,String engineType,float enginePrice) {
		this.engineId=engineId;
		this.engineType=engineType;
		this.enginePrice=enginePrice;
	}

	public int getEngineId() {
		return engineId;
	}

	public void setEngineId(int engineId) {
		this.engineId = engineId;
	}

	public String getEngineType() {
		return engineType;
	}

	public void setEngineType(String engineType) {
		this.engineType = engineType;
	}

	public float getEnginePrice() {
		return enginePrice;
	}

	public void setEnginePrice(float enginePrice) {
		this.enginePrice = enginePrice;
	}

	@Override
	public String toString() {
		return "EngineDetails [engineId=" + engineId + ", engineType=" + engineType + ", enginePrice=" + enginePrice
				+ "]";
	}
	

	
	
}
