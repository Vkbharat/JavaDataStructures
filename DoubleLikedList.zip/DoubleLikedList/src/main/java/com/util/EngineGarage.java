package com.util;

public class EngineGarage {

	private EngineGarage prev;
	private EngineDetails engineDetails;
	private EngineGarage next;
	
	public EngineGarage(EngineGarage prev,EngineDetails engineDetails,EngineGarage next) {
		this.prev=prev;
		this.engineDetails=engineDetails;
		this.next=next;
	}

	/**
	 * @return the prev
	 */
	public EngineGarage getPrev() {
		return prev;
	}

	/**
	 * @param prev the prev to set
	 */
	public void setPrev(EngineGarage prev) {
		this.prev = prev;
	}

	/**
	 * @return the engineDetails
	 */
	public EngineDetails getEngineDetails() {
		return engineDetails;
	}

	/**
	 * @param engineDetails the engineDetails to set
	 */
	public void setEngineDetails(EngineDetails engineDetails) {
		this.engineDetails = engineDetails;
	}

	/**
	 * @return the next
	 */
	public EngineGarage getNext() {
		return next;
	}

	/**
	 * @param next the next to set
	 */
	public void setNext(EngineGarage next) {
		this.next = next;
	}
	
	
	
}
