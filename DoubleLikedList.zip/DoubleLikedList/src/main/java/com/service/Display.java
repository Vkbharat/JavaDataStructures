package com.service;

import com.util.EngineGarage;

public class Display{
	
	public int displayFirstToLast(EngineGarage head)
	{
		if(head==null)
		{
			System.out.println("Empty List Dude: ");
			return 0;
		}
		//first to last logic
		do {
			System.out.println(head.getEngineDetails());
			head=head.getNext();
			}while(head!=null);
		return 0;
	}
	
	public int displayLastToFirst(EngineGarage head)
	{
		if(head==null)
		{
			System.out.println("Empty List Dude: ");
			return 0;
		}
		EngineGarage lastNode=null;
		
		//logic to get last Node
		while(head.getNext()!=null)			
			head=head.getNext();
		
		//initialize last node
		lastNode=head;
		
		//last to previous
		do {
			System.out.println(lastNode.getEngineDetails()+" ");
			lastNode=lastNode.getPrev();
			}while(lastNode!=null);
		return 0;
	}
}
