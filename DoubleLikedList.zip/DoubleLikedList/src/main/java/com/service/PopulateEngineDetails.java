package com.service;

import java.util.Scanner;
import com.util.EngineDetails;

public class PopulateEngineDetails {	
	private int number;
	private String type;
	private float price;
		
	public EngineDetails getDetails()
	{
		Scanner sc = new Scanner(System.in);		
		System.out.println("Enter the Engine Details:  ");
		System.out.print("Enter Engine number: ");
		number=sc.nextInt();
		System.out.println();
		System.out.print("Enter Engine Type: ");
		type=sc.next();
		System.out.println();
		System.out.print("Enter Engine Price: ");
		price=sc.nextFloat();
		
		//create Engine Details Object
		EngineDetails engineDetails = new EngineDetails(number, type,price);
		return engineDetails;
	}

	/**
	 * @return the number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + number;
		result = prime * result + Float.floatToIntBits(price);
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PopulateEngineDetails other = (PopulateEngineDetails) obj;
		if (number != other.number)
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}



}
