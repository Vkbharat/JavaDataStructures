package com.service;

import java.util.Scanner;

import com.util.EngineGarage;

public class DeleteNode {

	public EngineGarage deleteNode(EngineGarage head)
	{
		if(head==null)
		{
			System.out.println("Node is empty.. Nothin can be deleted");
			return head;
		}
		System.out.println("enter node postion to be deleted: ");
		Scanner sc=new Scanner(System.in);
		int pos=sc.nextInt();
		
		if(pos==0||pos>new NodeLength().getNodeCount(head))
		{
			System.out.println("You entered an incorrect position: ");
			return head;
		}
		//deletion of first node
		if(pos==1)
		{
			head=head.getNext();
			if(head.getNext()!=null)
				head.setPrev(null);
			System.out.println("**Deleted**\n");
			return head;
		}
		
		EngineGarage tempHead=head;
		int count=0;
		//middle or last node
		while(tempHead.getNext()!=null)
		{
			count++;
			if(count==pos)
				break;
			
			tempHead=tempHead.getNext();
		}
		
		tempHead.getPrev().setNext(tempHead.getNext());
		if(tempHead.getNext()!=null)
			tempHead.getNext().setPrev(tempHead.getPrev());
					
		//freeing it from pointing another nodes
		tempHead.setPrev(null);
		tempHead.setNext(null);
		
		System.out.println("**Deleted**\n");
		return head;
		
	}
	
	
}
