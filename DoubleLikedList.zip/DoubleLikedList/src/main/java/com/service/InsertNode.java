package com.service;

import java.util.Scanner;

import com.util.EngineDetails;
import com.util.EngineGarage;

public class InsertNode {
	
	NodeLength nodeLen=new NodeLength();
	
	public EngineGarage insertNode(EngineGarage head)
	{
		if(head==null)
		{
			System.out.println("Create nodes using chice 1: ");
			return head;
		}
		
		System.out.println("Enter the new node Position: ");
		Scanner sc=new Scanner(System.in);
		int pos=sc.nextInt();
		
		if(pos==0|| pos>nodeLen.getNodeCount(head)+1)
		{
			System.out.println("Wrong Node postion....");
			return head;
		}
		
		//Insertion at first pos
		if(pos==1)
		{
			EngineDetails engineDetails=new PopulateEngineDetails().getDetails();
			
			head=new EngineGarage(null, engineDetails, head);
			head.getNext().setPrev(head);
			return head;
		}
		
		//insertion at middle or last
		int count=1;
		EngineGarage tempHead=head;
		while(tempHead.getNext()!=null)
		{
			count++;
			if(count==pos)
			break;
			
			tempHead=tempHead.getNext();
		}
		EngineDetails engineDetails=new PopulateEngineDetails().getDetails();		
		tempHead.setNext(new EngineGarage(tempHead, engineDetails, tempHead.getNext()));
		if(tempHead.getNext().getNext()!=null) {
			//for middle Node
				tempHead.getNext().getNext().setPrev(tempHead.getNext());
}
		else{		
			//for last node
			tempHead.getNext().setPrev(tempHead);
		}					
		return head;
	}

}
