package com.service;

import java.util.Scanner;

import com.util.EngineGarage;

public class EditNodeData {
	Scanner sc=new Scanner(System.in);

	public void editData(EngineGarage head)
	{
		if(head==null)
		{
			System.out.println("Empty list");
			return;
		}
		System.out.println("Enter Node position: ");		
		int pos=sc.nextInt();
		
		if(pos==0||pos>new NodeLength().getNodeCount(head))
		{
			System.out.println("Invalid position");
			return;
		}		
		
		if(pos==1)
		{
			modification(head);
			return;
		}
		
		int count=1;
		while(head.getNext()!=null)
		{
			head=head.getNext();
			count++;
			if(count==pos)
				break;			
		}
		modification(head);
		return;
	}
	
	private void modification(EngineGarage tempHead)
	{
		System.out.println("To modify Engine Id: Press 1 , 0 to skip");
		int input=sc.nextInt();
		if(input==1)
		{
			System.out.println("Enter new engine Id: ");
			int engineId=sc.nextInt();
			tempHead.getEngineDetails().setEngineId(engineId);
			System.out.println("**Engine Id updated**\n");
		}
		
		System.out.println("To modify Engine Type: Press 1, 0 to skip");
		input=sc.nextInt();
		if(input==1)
		{
			System.out.println("Enter new engine Type: ");
			String engineType=sc.next();
			tempHead.getEngineDetails().setEngineType(engineType);
			System.out.println("**Engine Type updated**\n");
		}
		
		System.out.println("To modify Engine Id: Press 1, 0 to skip");
		input=sc.nextInt();
		if(input==1)
		{
			System.out.println("Enter new engine Price: ");
			float enginePrice=sc.nextFloat();
			tempHead.getEngineDetails().setEnginePrice(enginePrice);
			System.out.println("**Engine Price updated**\n");
		}
	}
	
}
