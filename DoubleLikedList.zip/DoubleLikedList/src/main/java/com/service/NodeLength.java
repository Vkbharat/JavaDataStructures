package com.service;

import com.util.EngineGarage;

public class NodeLength {
	
	public int getNodeCount(EngineGarage head)
	{
		if(head==null)
			return 0;
		
		int count=1;
		while(head.getNext()!=null)
		{
			count++;
			head=head.getNext();
		}
		return count;
	}

}
