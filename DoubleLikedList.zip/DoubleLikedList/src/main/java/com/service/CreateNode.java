package com.service;

import com.util.EngineDetails;
import com.util.EngineGarage;

public class CreateNode {
	
	PopulateEngineDetails populateEngineDetails=new PopulateEngineDetails();

	public EngineGarage createNode(EngineGarage head)
	{
		if(head==null)
		{			
			EngineDetails engineDetails=populateEngineDetails.getDetails();
			return head=new EngineGarage(null, engineDetails,null);
		}
		
		EngineGarage tempHead=head;
		
		//last node addition
		while(tempHead.getNext()!=null)
		{
			tempHead=tempHead.getNext();
		}
		EngineDetails engineDetails=populateEngineDetails.getDetails();
		tempHead.setNext(new EngineGarage(tempHead,engineDetails,null));
		
		return head;
	}
	
	
}
