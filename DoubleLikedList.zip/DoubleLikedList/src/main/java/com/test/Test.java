package com.test;

import java.util.Scanner;
import com.service.CreateNode;
import com.service.DeleteNode;
import com.service.Display;
import com.service.EditNodeData;
import com.service.InsertNode;
import com.service.NodeLength;
import com.util.EngineGarage;

public class Test {
	private static boolean flag=true;
	private static EngineGarage head=null;
	
	public static void main(String[] args) {						
		CreateNode create=new CreateNode();
		Display disp=new Display();
		InsertNode insert=new InsertNode();
		NodeLength nodeLen=new NodeLength();
		DeleteNode delNode=new DeleteNode();
		EditNodeData editNodeData=new EditNodeData();
		
		while(flag)
		{
			System.out.println("\n**Choices**\n");
			System.out.println("1: To Create a Node");
			System.out.println("2. To display First to Last");
			System.out.println("3. To display Last to first");
			System.out.println("4: To Insert a new Node");
			System.out.println("5: To get Node Count or Node Length");
			System.out.println("6: To delete a node");
			System.out.println("7: To edit a node data");
			System.out.println("8: To detect Loop");
			System.out.println("10. To quit");
			
			Scanner sc=new Scanner(System.in);
			int key=sc.nextInt();
			
			switch (key) {
			case 1:	head=create.createNode(head);		
				break;
			case 2:disp.displayFirstToLast(head);
				break;
			case 3:disp.displayLastToFirst(head);
				break;
			case 4:head=insert.insertNode(head);
				break;
			case 5:int len=nodeLen.getNodeCount(head);
				System.out.println("Lenght is: "+len);
				break;
			case 6:head=delNode.deleteNode(head);
				break;
			case 7:editNodeData.editData(head);
				break;
			case 10:
				System.out.println("\n Thank You!!");
				System.out.println("**Visit Again**\n");
				break;
			default:
				break;
			}												
		}				
	}
}
