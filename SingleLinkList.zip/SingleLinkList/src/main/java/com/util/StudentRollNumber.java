package com.util;

public class StudentRollNumber {
	
	int data;
	StudentRollNumber next;
	
	public StudentRollNumber(int data,StudentRollNumber next) {
		this.data=data;
		this.next=next;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	public StudentRollNumber getNext() {
		return next;
	}

	public void setNext(StudentRollNumber next) {
		this.next = next;
	}
	
}
