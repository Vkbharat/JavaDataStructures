package com.test;

import java.util.Scanner;

import com.service.CreateNodeService;
import com.service.DeleteNode;
import com.service.DisplayService;
import com.service.EditNodeData;
import com.service.NodeCount;
import com.util.StudentRollNumber;

public class Test {	
	static boolean flag=true;
	static StudentRollNumber head=null;
	public static void main(String[] args) {
		
		CreateNodeService cns=new CreateNodeService();
		DisplayService disp=new DisplayService();
		NodeCount nc=new NodeCount();
		EditNodeData end=new EditNodeData();
		DeleteNode delNode=new DeleteNode();
		
		while(flag)
		{
			System.out.println("1.To add a node");
			System.out.println("2.To display");
			System.out.println("3.To edit a node data");
			System.out.println("4.To delete a node data");
			System.out.println("5.Total Node Count");
			System.out.println("6.To quit");
			
			Scanner scanner = new Scanner(System. in);
			int key=scanner.nextInt();
			
			switch (key) {
			case 1:
				head=cns.createNode(head);
				break;
				
			case 2:
				disp.display(head);
				break;
				
			case 3:		
				end.editNode(head);
				break;
				
			case 4:		
				head=delNode.deleteNode(head);
				break;
				
			case 5:
				nc.getCount(head);
				break;
				
			case 6:
				System.out.println("Thank You For Using our Services");
				flag=false;
				break;
				
			default:
				System.out.println("Read and Enter the key carefully");
				break;
			}									
		}				
	}
}
