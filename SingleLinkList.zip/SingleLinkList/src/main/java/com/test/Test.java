package com.test;

import java.util.Scanner;

import com.service.CreateNodeService;
import com.service.DisplayService;
import com.util.StudentRollNumber;

public class Test {	
	static boolean flag=true;
	static StudentRollNumber head=null;
	public static void main(String[] args) {
		
		CreateNodeService cns=new CreateNodeService();
		DisplayService disp=new DisplayService();
		
		while(flag)
		{
			System.out.println("1.To add a node");
			System.out.println("2.To display");
			System.out.println("3.To quit");
			
			Scanner scanner = new Scanner(System. in);
			int key=scanner.nextInt();
			
			switch (key) {
			case 1:
				head=cns.createNode(head);
				break;
				
			case 2:
				disp.display(head);
				break;
			case 3:
				System.out.println("Thank You For Using my Services");
				flag=false;
				break;
			default:
				System.out.println("Read and Enter the key carefully");
				break;
			}
									
		}				
	}
}
