package com.service;

import com.util.StudentRollNumber;

public class DisplayService {
	
	public int display(StudentRollNumber head)
	{
		//in case of no node
		if(head==null)
		{
			System.out.println("Its an empty list dude");		
			System.out.println("***********       **********");
			System.out.println();
			return 0;
		}
		
		//if some node is there	
		do {
			System.out.print(head.getData()+" ");
			head=head.getNext();
		}while(head!=null);
		System.out.println("\n"+"Thank You For Using Our Display Services");
		System.out.println();
		return 0;
	}

}
