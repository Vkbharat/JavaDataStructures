package com.service;

import java.util.Scanner;

import com.util.StudentRollNumber;

public class DeleteNode {
	
	NodeCount nc=new NodeCount();
	
	public StudentRollNumber deleteNode(StudentRollNumber head)
	{
		System.out.println("Enter the node pos: ");
		Scanner sc=new Scanner(System.in);
		int pos=sc.nextInt();
		
		if(pos==0 || pos>nc.getCount(head))
		{
			System.out.println("Idiot!!!! You Entered a wrong Position\n");
			return head;
		}
		
		//deleting first node
		if(pos==1)
		{
			StudentRollNumber tempHead=head;
			head=head.getNext();
			tempHead=null;
			System.out.println("**Deleted**\n");
			return head;
		}
		
		//deleting last or middle node
		StudentRollNumber prevtoDeleteNode=head;
		StudentRollNumber nexttoDeleteNode=null;
		int count=1;
		
		while(prevtoDeleteNode.getNext()!=null)
		{
			count++;
			if(count==pos)
				break;
			prevtoDeleteNode=prevtoDeleteNode.getNext();
		}
		nexttoDeleteNode=(prevtoDeleteNode.getNext()!=null)?prevtoDeleteNode.getNext().getNext():null;
		prevtoDeleteNode.setNext(nexttoDeleteNode);
		System.out.println("**Deleted**\n");
		return head;
	}

}
