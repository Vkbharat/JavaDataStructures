package com.service;

import com.util.StudentRollNumber;

public class DetectLoop {
	
	private boolean flag=false;
	
	//using floyd's cycle
	public StudentRollNumber detectLooping(StudentRollNumber head)
	{
		StudentRollNumber slowref=head;
		StudentRollNumber fastref=head;
		
		if(head==null)
		{
			System.out.println("Empty list: ");
			return null;
		}
		
		while(slowref!=null && fastref!=null && fastref.getNext()!=null)
		{
			slowref=slowref.getNext();
			fastref=fastref.getNext().getNext();
			
			if(slowref==fastref)
			{
				flag=true;
				break;
			}
		}
		if(flag)
		{
			System.out.println("loop detected at: "+slowref.getData());
			return slowref;
		}
		else
		{
			System.out.println("No loop detected");
			return null;
		}
		
	}

}
