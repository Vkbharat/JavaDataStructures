package com.service;

import com.util.StudentRollNumber;

public class NodeCount {	
	public int getCount(StudentRollNumber head)
	{
		if(head==null)
		{
			System.out.println("Empty list always have 0 nodes dude\n");
			return 0;
		}
		StudentRollNumber tempHead=head;
		int count=1;
		
		while(tempHead.getNext()!=null)
		{
			count++;
			tempHead=tempHead.getNext();
		}
		System.out.println("Total Nodes: "+count+"\n");
		return count;
	}
}
