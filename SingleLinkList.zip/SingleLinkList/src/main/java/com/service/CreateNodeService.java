package com.service;

import java.util.Scanner;

import com.util.StudentRollNumber;

public class CreateNodeService {
	
	StudentRollNumber tempHead=null;

	public StudentRollNumber createNode(StudentRollNumber head)
	{
		//first node logic
		if(head==null)
		{
			System.out.println("Enter the Roll Data: ");
			Scanner scanner = new Scanner(System. in);
			int data=scanner.nextInt();
						
			head=new StudentRollNumber(data, null);			
			return head;
		}
		
		//last node logic		
		tempHead=head;
		StudentRollNumber next;
		while(tempHead.getNext()!=null)
		{
			tempHead=tempHead.getNext();
		}
		
		System.out.println("Enter the Roll Data: ");
		Scanner scanner = new Scanner(System. in);
		int data=scanner.nextInt();
		
		next=new StudentRollNumber(data, null); 
		tempHead.setNext(next);
		
		return head;
	}

	
}
