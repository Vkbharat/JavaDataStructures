package com.service;

import java.util.Scanner;

import com.util.StudentRollNumber;

public class InsertNode {
	
	public StudentRollNumber insertNode(StudentRollNumber head)
	{
		NodeCount nc=new NodeCount();	
		
		System.out.println("Enter the new Node position: ");
		Scanner sc=new Scanner(System.in);
		int pos=sc.nextInt();
		
		if(pos==0||pos>nc.getCount(head)+1)
		{
			System.out.println("Are you insane....");
			System.out.println("Enter correct Node position Bhai..");			
			return head;
		}
		
		System.out.println("Enter new node Data: ");
		int data=sc.nextInt();
		
		//FirstNode Modification
		if(pos==1)
		{
			head=new StudentRollNumber(data,head);
			System.out.println("**Added**\n");
			return head;
		}
		
		StudentRollNumber tempHead=head;
		StudentRollNumber tempHead2;
		int count=1;
		
		//middle or last
		while(tempHead.getNext()!=null)
		{
			count++;
			if(count==pos) {
				break;		
			}
			tempHead=tempHead.getNext();
		}
		
		//tempHead.getNext()==null in case of last node
		tempHead2=(tempHead.getNext()!=null)?
				new StudentRollNumber(data,tempHead.getNext())
				:new StudentRollNumber(data, null);
				
				tempHead.setNext(tempHead2);		
				System.out.println("**Added**\n");
		return head;
	}

}
