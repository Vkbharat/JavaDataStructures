package com.service;

import java.util.Scanner;

import com.util.StudentRollNumber;

public class EditNodeData {
	
	NodeCount nc=new NodeCount();

	public int editNode(StudentRollNumber head)
	{
		System.out.println("Enter the node position: ");
		Scanner sc=new Scanner(System.in);
		int pos=sc.nextInt();
		
		if(pos>nc.getCount(head)|| pos==0)
		{
			System.out.println("What are you doing man.. node position doesn't exist\n");
			System.out.println("Enter correct node pos\n");
			return 0;
		}
		
		//first node data modification
		if(pos==1)
		{
			System.out.println("Enter the new data...");
			int data=sc.nextInt();
			head.setData(data);
			System.out.println("**Edited**\n");
			return 0;
		}
		
		//middle or last node data modification
		int count=1;
		StudentRollNumber tempHead=head;
		while(tempHead.getNext()!=null)
		{
			tempHead=tempHead.getNext();
			count++;
			if(count==pos)
				break;
		}
		System.out.println("Enter the new data...");
		int data=sc.nextInt();
		tempHead.setData(data);
		System.out.println("**Edited**\n");
		return 0;
	}		
}
