package com.service;

import com.util.StudentRollNumber;

public class RecursionNodeCount {

	public int getNodeCount(StudentRollNumber head)
	{		
		if(head==null)
		{			
			return 0;
		}

		return 1+getNodeCount(head.getNext());
	}
	
	
	
}
