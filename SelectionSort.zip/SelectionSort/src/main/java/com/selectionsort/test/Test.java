package com.selectionsort.test;

import com.selectionsort.serivce.SelectionSort;

public class Test {

	public static void main(String[] args) {
		
		SelectionSort ss=new SelectionSort();

		int[] array=new int[10];
		
		//popuate array
		array[1]=10;array[2]=-10;array[4]=20;array[6]=110;array[8]=50;
		array[1]=20;array[3]=-1;array[5]=90;array[7]=8;array[9]=70;
		
		System.out.print("Unsorted array: ");
		for(int i:array)
		{
			System.out.print(i+" ");
		}
		System.out.println();
		array=ss.sort(array);
		System.out.print("Sorted array: ");		
		for(int i:array)
		{
			System.out.print(i+" ");
		}
	}
}
