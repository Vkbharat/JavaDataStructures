package com.selectionsort.serivce;

public class SelectionSort {
	
	/*
	 * In selection sort sorting algorithm we used to sort the elements in a
	 * sequential way unlike bubble i.e. adjacent comparison. Here one element is
	 * compared to others and smallest get set first.
	 */

	public int[] sort(int[] array)
	{
		for(int i=0;i<array.length-1;i++)
		{
			for(int j=i+1;j<array.length;j++)
			{
				if(array[i]>array[j])
					swap(array,i,j);
			}
		}				
		return array;
	}
	
	//swapping using xor operator
	public void swap(int[] array,int i,int j)
	{
		array[i]^=array[j];
		array[j]=array[i]^array[j];
		array[i]^=array[j];
		
	}
	
}
